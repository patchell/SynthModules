200-1021.DRL.....drill file (binary)
200-1021.DRR.....tool table
200-1021.GBL.....GERBER FILE:circuit side
200-1021.GBS.....GERBER FILE:circuit/component solder mask
200-1021.GD1.....GERBER FILE:fab drawing
200-1021.GTL.....GERBER FILE:component side
200-1021.GTO.....GERBER FILE:component legend
200-1021.TXT.....drill file (ascii)

files created with protel v2.7
Jim Patchell
patchell@cox.net
805-689-9102

