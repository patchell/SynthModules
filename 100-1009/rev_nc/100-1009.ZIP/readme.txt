100-1009.DRL.....Drill File, Binary
100-1009.DRR.....Drill File, Tool Table
100-1009.GBL.....Gerber File, Circuit Side
100-1009.GBS.....Gerber File, Top and Bottom Solder mask
100-1009.GD1.....Gerber File, Drill/Fab drawing
100-1009.GTL.....Gerber File, Component Side
100-1009.GTO.....Gerber File, Component Legend
100-1009.TXT.....Drill File, Ascii

Files Created with Protel V2.7
Jim Patchell
patchell@silcom.com
805-689-9102

