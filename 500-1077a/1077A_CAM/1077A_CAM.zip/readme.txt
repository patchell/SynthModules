 Volume in drive C has no label.
 Volume Serial Number is ECEE-55DF

 Directory of C:\Documents and Settings\Jim Patchell\My Documents\projects\SynthMod\500-1077a\1077A_CAM

06/18/2014  09:12 PM    <DIR>          .
06/18/2014  09:12 PM    <DIR>          ..
06/18/2014  08:50 PM             2,059 1077.DRL----binary drill file
06/18/2014  08:50 PM             1,215 1077.DRR----AScii Tool Table
06/18/2014  08:56 PM            19,359 1077.GBL----Gerber Circuit Side
06/18/2014  08:56 PM             9,971 1077.GBS----Gerber Solder mask
06/18/2014  09:03 PM            44,250 1077.GD1----Gerber FAB drawing
06/18/2014  08:56 PM            19,739 1077.GTL----Gerber Component side
06/18/2014  08:56 PM            99,830 1077.GTO----Gerber Component Legend
06/18/2014  08:50 PM             2,351 1077.TXT----Ascii Drill File
06/18/2014  09:12 PM                 0 readme.txt
               9 File(s)        198,774 bytes
               2 Dir(s)  39,745,884,160 bytes free
