1001010.TXT.....ASCII NC Drill Data
1001010.DRR.....Tool Table for NC Drill (ASCII)
1001010.GBL.....Gerber File Circuit Side
1001010.GBS.....Gerber File Circuit Side Solder Mask
1001010.GD1.....Gerber File Drill Drawing
1001010.GTL.....Gerber File Component Side
1001010.GTO.....Gerber File Component Side Legend
1001010.GTS.....Gerber File Component Side Solder Mask
1001010.DRL.....Binary NC Drill Data
Files Created with Protel V2.7
Jim Patchell
805-879-7407 (day)
