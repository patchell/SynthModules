100-1056.DRL.............Drill File (Binary)
100-1056.DRR.............Tool Table (Ascii)
100-1056.GBL.............Circuit Side (GERBER)
100-1056.GBS.............Solder Mask (top/bottom) (GERBER)
100-1056.GD1.............Fab Drawing (GERBER)
100-1056.GTL.............Component Side (GERBER)
100-1056.GTO.............Component Side Legend (GERBER)
100-1056.TXT.............Drill File (ASCII)
readme.txt...............This file

Circuit board created with Protel 2.7
James Patchell
118 San Milano Drive
Goleta CA 93117
805-681-2455 (day)
805-685-1878 (eve)
805-280-2297 (cell phone)

