200-1016.DRL....drill file (binary)
200-1016.DRR....tool table (ascii)
200-1016.GBL....gerber file:circuit side
200-1016.GBS....gerber file:circuit/component solder mask
200-1016.GD1....gerber file:fab drawing
200-1016.GTL....gerber file:component side
200-1016.GTO....gerber file:component legend
200-1016.TXT....drill file (ascii)
