200-1038.DRL.......drill file binary
200-1038.DRR.......tool table
200-1038.GBL.......circuit side gerber
200-1038.GBS.......circuit/component side solder mask gerber
200-1038.GD1.......fab drawing gerber
200-1038.GTL.......component side gerber
200-1038.GTO.......component side legend
200-1038.TXT.......drill file ascii

files created with Protel V2.7
Jim Patchell
118 San Milano Drive
Goleta, CA 93117
805-685-1878
805-689-9102
805-681-2307
patchell@cox.net

