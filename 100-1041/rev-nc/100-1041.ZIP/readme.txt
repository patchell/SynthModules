100-1041.DRL........drill file binary
100-1041.DRR........tool table
100-1041.GBL........circuit side gerber
100-1041.GBS........solder mask component/circuit gerber
100-1041.GD1........fab drawing gerber
100-1041.GTL........component side gerber
100-1041.GTO........component legend gerber
100-1041.TXT........drill file ascii

files created with protel v2.7
Jim Patchell
118 San Milano Drive
Goleta, CA 93117
805-685-1878 (eve)
805-689-9102 (cell)
805-681-2307 (day)

