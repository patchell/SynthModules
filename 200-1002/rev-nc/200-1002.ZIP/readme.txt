200-1002.DRL......Drill File (Binary)
200-1002.DRR......Tool Table (ascii)
200-1002.GBL......Gerber File:Bottom Layer
200-1002.GBS......Gerber File:Top/Bottom Solder mask
200-1002.GD1......Gerber File:Fab Drawing
200-1002.GTL......Gerber File:Top Layer
200-1002.GTO......Gerber File:Top Legend
200-1002.TXT......Drill File (Ascii)

Jim patchell
805-689-9102
patchell@cox.net
Files created with Protel Version 2.7

