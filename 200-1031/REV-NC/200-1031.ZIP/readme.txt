200-1031.DRL.....drill file:binary
200-1031.DRR.....tool table:ascii
200-1031.GBL.....gerber file:circuit side
200-1031.GBS.....gerber file:component/circuit side
200-1031.GD1.....gerber file:fab drawing
200-1031.GTL.....gerber file:component side
200-1031.GTO.....gerber file:legend
200-1031.TXT.....drill file:ascii

files created with protel 2.7
patchell@cox.net
805-689-9102
Jim Patchell

