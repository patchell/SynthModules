200-1030.DRL.....drill file (binary)
200-1030.DRR.....tool table (ascii)
200-1030.GBL.....Gerber File:circuit side
200-1030.GBS.....gerber file:top/bottom solder mask
200-1030.GD1.....gerber file:fab drawing
200-1030.GTL.....gerber file:component side
200-1030.GTO.....gerber file:component side legend
200-1030.TXT.....drill file:(ascii)
