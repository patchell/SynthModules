100-1015.DRL.......drill file binary
100-1015.DRR.......tool table
100-1015.GBL.......circuit side gerber
100-1015.GBS.......circuit/component solder mask gerber
100-1015.GD1.......fab drawing gerber
100-1015.GTL.......component side gerber
100-1015.GTO.......component side legend gerber
100-1015.TXT.......drill file ascii

files create with protel v2.7
Jim Patchell
118 San Milano Drive
Goleta CA 93117
805-685-1878 (eve)
805-689-9102 (cell)
805-681-2307 (day)
patchell@cox.net

