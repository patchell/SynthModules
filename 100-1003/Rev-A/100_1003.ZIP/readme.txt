	These files were created with Protel V2.7
	Gerber File have embedded aperatures

100_1003.DRR	Tool Table Ascii
100_1003.TXT	Ascii Drill File
100_1003.DRL	EIA Drill File
100_1003.GTL	Gerber File Component Side
100_1003.GBL	Gerber File Circuit Side
100_1003.GTO	Gerber File Component Side Legend
100_1003.GBS	Gerber File Solder Mask Compoent and Ciruit Side
100_1003.GD1	Gerber File fab Drawing

	Jim Patchell
	118 San Milano Drive
	Goleta, CA 93117
	805-968-4333 (day)
	805-685-1878 (eve)
	patchell@silcom.com
