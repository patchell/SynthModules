1001013.DRL....Binary NC Drill DAta
1001013.DRR....NC Tool Table (ascii)
1001013.GBL....Gerber File Circuit Side
1001013.GBS....Gerber File Circuit Side Solder Mask
1001013.GD1....Gerber File Drill Drawing
1001013.GTL....Gerber File Component Side
1001013.GTO....Gerber File Component Side Legend
1001013.GTS....Gerber File Component Side Solder Mask
1001013.TXT....ASCII NC Drill Data
Files Created with Protel V2.7
Jim Patchell
805-879-7407 (day)