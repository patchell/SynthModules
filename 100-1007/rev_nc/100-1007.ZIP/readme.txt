100-1007.DRL.....Binary Drill File
100-1007.DRR.....Drill Tool Table
100-1007.GBL.....Gerber File, Circuit Side
100-1007.GBS.....Gerber File, Top and Bottom solder mask
100-1007.GD1.....Gerber File, Fab Drawing
100-1007.GTL.....Gerber File, Component Side
100-1007.GTO.....Gerber File, Component Legend
100-1007.TXT.....Ascii Drill File

Files Created with Protel V2.7
Jim Patchell
patchell@silcom.com
805-689-9102

