200-1007.DRL......Drill File (binary)
200-1007.DRR......Tool Table (ascii)
200-1007.GBL......Gerber File:Circuit Side
200-1007.GBS......Gerber File:Ciruit/Component Side
200-1007.GD1......Gerber File:Fab Drawing
200-1007.GTL......Gerber File:Component Side
200-1007.GTO......Gerber File:Component Legend
200-1007.TXT......Drill File (ascii)

Files created with Protel V2.7
Jim Patchell
patchell@cox.net
805-689-9102

