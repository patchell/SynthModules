2001018.DRL.....drill file (binary)
2001018.DRR.....tool table (ascii)
2001018.GBL.....gerber file:circuit side
2001018.GBS.....gerber file:component/circuit side solder mask
2001018.GD1.....gerber file:fab drawing
2001018.GTL.....gerber file:component side
2001018.GTO.....gerber file:component legend
2001018.TXT.....drill file (ascii)

files created with protel v2.7
jim patchell
patchell@cox.net
805-689-9102

