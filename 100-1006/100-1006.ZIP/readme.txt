	The files were created with Protel V2.7
	Gerber Files have Embedded Aperatures

100-1006.DRR	Tool Table Ascii
100-1006.TXT	Ascii Drill File
100-1006.DRL	EIA Drill File
100-1006.GTL	Gerber File Component Side
100-1006.GBL	Gerber File Circuit Side
100-1006.GTO	Gerber File Component Side Legend
100-1006.GBS	Gerber File Solder Mask, Component and Circuit Side
100-1006.GD1	Gerber File Fab Drawing
