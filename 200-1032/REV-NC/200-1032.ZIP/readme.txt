200-1032.DRL......Drill File (Binary)
200-1032.DRR......Tool Table (Ascii)
200-1032.GBL......Gerber File:Circuit Side
200-1032.GBS......Gerber File:Circuit/Component Side solder mask
200-1032.GD1......Gerber File:Fab Drawing
200-1032.GTL......Gerber File:Component Side
200-1032.GTO......Gerber File:Component Legend
200-1032.TXT......Drill File (Ascii)

