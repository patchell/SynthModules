200-1039.DRL......drill file binary
200-1039.DRR......tool table
200-1039.GBL......circuit side (gerber)
200-1039.GBS......circuit/component side solder mask (gerber)
200-1039.GD1......fab drawing (gerber)
200-1039.GTL......component side (gerber)
200-1039.GTO......component side legend (gerber)
200-1039.TXT......drill file ascii

files created with Protel V2.7
Jim Patchell
118 San Milano Drive
Goleta, CA 93117
805-681-2307 (day)
805-689-9102 (cell)
805-685-1878 (eve)
patchell@cox.net

