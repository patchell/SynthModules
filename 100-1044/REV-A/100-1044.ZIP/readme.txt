100-1044.DRL...........Binary Drill Data
100-1044.DRR...........Tool Table (ascii)
100-1044.GBL...........(Gerber)Circuit Side
100-1044.GBS...........(Gerber)Solder mask circuit/component side
100-1044.GD1...........(Gerber) Fab Drawing
100-1044.GTL...........(Gerber)Component side
100-1044.GTO...........(Gerber)Component side legend
100-1044.TXT...........Drill Data (ascii)

James Patchell
805-681-2307 (day)
805-685-1878 (eve/weekends)
805-689-9102 (cell...last resort)
patchell@cox.net
Files created with protel V2.7

