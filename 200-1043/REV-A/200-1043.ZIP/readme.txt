200-1043.DRL.......Drill File (Binary)
200-1043.DRR.......Drill Tool Table (ascii)
200-1043.GBL.......Gerber File-Circuit side
200-1043.GBS.......Gerber File-Soldermask Circuit/component side
200-1043.GD1.......Gerber File-Fab Drawing
200-1043.GTL.......Gerber File-Component Side
200-1043.GTO.......Gerber File-Component Legend
200-1043.TXT.......Drill File (ascii)

James Patchell
805-681-2307 (day phone-voice mail)
805-685-1878 (eve phone)
805-689-9102 (cell phone-voice mail)

Files were created with Protel Version 2.7
